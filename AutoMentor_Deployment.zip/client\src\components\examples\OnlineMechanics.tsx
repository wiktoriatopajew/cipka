import OnlineMechanics from '../OnlineMechanics';

export default function OnlineMechanicsExample() {
  return (
    <div className="max-w-md mx-auto">
      <OnlineMechanics />
    </div>
  );
}